Image Comparison Slider
=========

A handy draggable slider to quickly compare 2 images, powered by CSS3 and jQuery.

[Article on CodyHouse](http://codyhouse.co/gem/css-jquery-image-comparison-slider/)

[Demo](http://codyhouse.co/demo/image-comparison-slider/index.html)
 
[Terms](http://codyhouse.co/terms/)
